1. Unzip 
2. Upload folder Light to /var/www/controlpanel/themes
3. Upload folder LightTheme to /var/www/controlpanel/public/themes
4. Enjoy. 
